﻿#ifndef SIXJOINTS_H
#define SIXJOINTS_H

#include <QDialog>
#include "Platform.h"


namespace Ui {
class SixJoints;
}

class SixJoints : public QDialog
{
    Q_OBJECT

public:
    explicit SixJoints(QWidget *parent = 0);
    ~SixJoints();
    bool GetJoints(QVector<double> &joints);
    bool GetJoints(double xp, double yp, double zp, double ap, double bp, double cp, QVector<double> &joints);

signals:
    void TCPChanged(QVector<qreal> pos);
    void UpdateJoints(QVector<double> joints);

public slots:
    void onTCPValueChanged0();
    void onTCPValueChanged1();

    void on_pushButtonReset_clicked();
    void on_pushButtonOri_clicked();

    void SetPos(double xp, double yp, double zp, double ap, double bp, double cp);
    void SetPos(QVector<double> pos);
private:
    Ui::SixJoints *ui;
    Platform stewart;
};

#endif // SIXJOINTS_H
