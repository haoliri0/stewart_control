﻿#include "SixJoints.h"
#include "ui_SixJoints.h"
#include "QDoubleSpinBox"
#include "QSlider"
const char indexPropertyName[] = "index";

SixJoints::SixJoints(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SixJoints)
{
    ui->setupUi(this);

    //轴控制模式下为每一个slider设置量程及零点
    //TCP模式下，为每一个slider设置量程及零点
    for (int index = 1; index <= 6; index++) {
        QSlider *slider = findChild<QSlider *>(QString("verticalSliderTCP%1").arg(index));
        QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(index));

        slider->setMaximum(stewart.range[index - 1][2]);
        slider->setMinimum(stewart.range[index - 1][0]);
        slider->setValue(stewart.range[index - 1][1]);

        doubleSpinBox->setMaximum(stewart.range[index - 1][2]);
        doubleSpinBox->setMinimum(stewart.range[index - 1][0]);
        doubleSpinBox->setValue(stewart.range[index - 1][1]);

        connect(doubleSpinBox, SIGNAL(valueChanged(double)), this, SLOT(onTCPValueChanged0()));
        connect(slider, SIGNAL(valueChanged(int)), this, SLOT(onTCPValueChanged1()));
        doubleSpinBox->setProperty(indexPropertyName, index);
        slider->setProperty(indexPropertyName, index);
    }
    //设置TCP模式不可用
    ui->groupBoxTCP->setEnabled(1);
}

SixJoints::~SixJoints()
{
    delete ui;
}

bool SixJoints::GetJoints(QVector<double> &joints)
{
    if (stewart.GetJoints(joints)) {
        return true;
    } else {
        return false;
    }
}

bool SixJoints::GetJoints(double xp, double yp, double zp, double ap, double bp, double cp, QVector<double> &joints)
{
    if (stewart.GetJoints(xp, yp, zp, ap, bp, cp, joints)) {
        return true;
    } else {
        return false;
    }
}

/*!
 * \brief SixJoints::onTCPValueChanged              由spinBox触发后，更改slider的值，并将TCP发射出去
 */
void SixJoints::onTCPValueChanged0()
{
    //spinBox的变化引起slider的变化
    QObject *doubleSpinBox = sender();
    if (!doubleSpinBox) {
        return;
    }
    bool ok = false;
    int index = doubleSpinBox->property(indexPropertyName).toInt(&ok);
    if (!ok) {
        return;
    }
    QDoubleSpinBox *temp = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(index));
    QSlider *slider = findChild<QSlider *>(QString("verticalSliderTCP%1").arg(index));
    slider->setValue((int)(temp->value()));

    //发射TCP变化的信号给串口
    QVector<qreal> TCP(6,0);
    for (int id = 1; id <= 6; id++) {
        QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(id));
        TCP[id - 1] = doubleSpinBox->value();
    }
    emit TCPChanged(TCP);

}
/*!
 * \brief SixJoints::onTCPValueChanged1             由slider触发后，更改spinbox的值
 */
void SixJoints::onTCPValueChanged1()
{
    //slider的变化引起spinbox的变化
    QObject *sliderSender = sender();
    if (!sliderSender) {
        return;
    }
    bool ok = false;
    int index = sliderSender->property(indexPropertyName).toInt(&ok);
    if (!ok) {
        return;
    }
    QSlider *slider = findChild<QSlider *>(QString("verticalSliderTCP%1").arg(index));
    QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(index));
    doubleSpinBox->setValue((qreal)(slider->value()));

    QVector<double> pos(6);
    for (int id = 1; id <=6; ++id) {
        QDoubleSpinBox *spinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(id));
        pos[id - 1] = spinBox->value();
    }
    SetPos(pos);
}
/*!
 * \brief SixJoints::on_pushButtonReset_clicked     响应“复位”按键
 */
void SixJoints::on_pushButtonReset_clicked()
{
    for (int index = 1; index <= 6; index++) {
        QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(index));
        doubleSpinBox->setValue(stewart.range[index - 1][1]);
    }
}
/*!
 * \brief SixJoints::on_pushButtonOri_clicked       响应“标零”按键
 */
void SixJoints::on_pushButtonOri_clicked()
{
    QVector<qreal> temp(6);
    for (int index = 1; index <= 6; index++) {
//        QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxJ%1").arg(index));
//        temp[index - 1] = doubleSpinBox->value();
    }
}

void SixJoints::SetPos(double xp, double yp, double zp, double ap, double bp, double cp)
{
    stewart.SetPos(xp, yp, zp, ap, bp, cp);
    QVector<double> joints(6);
    if (stewart.GetJoints(joints)) {
        emit UpdateJoints(joints);
    }
}

void SixJoints::SetPos(QVector<double> pos)
{
    stewart.SetPos(pos);
    QVector<double> joints(6);
    if (stewart.GetJoints(joints)) {
        emit UpdateJoints(joints);
        for (int index = 1; index <= 6; ++index) {
            QLabel *label = findChild<QLabel *>(QString("joint%1").arg(index));
//            QDoubleSpinBox *doubleSpinBox = findChild<QDoubleSpinBox *>(QString("doubleSpinBoxTCP%1").arg(index));
//            label->setText( QString("%1").arg(doubleSpinBox->value()));
            label->setText( QString("%1").arg(joints.at(index - 1)));
        }
    }
}


