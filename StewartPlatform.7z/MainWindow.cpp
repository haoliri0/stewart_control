﻿#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "SixJoints.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    sixJoints = new SixJoints();
    setCentralWidget(sixJoints);
}

MainWindow::~MainWindow()
{
    delete ui;
}
